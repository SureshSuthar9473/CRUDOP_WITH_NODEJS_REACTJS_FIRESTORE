# NodeJSxFirestoreCURD
API per fer CRUD a firestore

Exemple a:

```
https://firebasexnode-2hlxxltleq-ew.a.run.app/
```

# Guia d'instal·lació

Descarregar el codi

```
git clone https://github.com/BlackkSight/NodeJSxFirestoreCURD.git
```

Entrar a la carpeta del projecte i instal·lar les dependencies

```
npm install
```
Introduïr les credencials a la carpeta del projecte amb el nom "firestore.json"

```
mv ~/Downloads/firestore.json .
```

Executar el servidor

```
npm start
```
# Guia de desplegament a GCP

Executar el següent comandament per fer ús de Cloud Run

```
gcloud run deploy
```
